{
	"name": "Wang Bot Multi Device "
}